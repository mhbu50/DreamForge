// Optional particles component - can be enabled/disabled
export default function Particles() {
  return null; // Particles removed in redesign for cleaner look
}
