import React, { useState, useEffect } from 'react';
import { auth, db } from '../firebase';
import { signInWithPopup, GoogleAuthProvider, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from '../lib/firestore-utils';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, LogIn, UserPlus, Loader2, X, FileText, Mail, Lock } from 'lucide-react';
import { toast } from 'sonner';

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [showLegal, setShowLegal] = useState<{ show: boolean, type: 'terms' | 'privacy' }>({ show: false, type: 'terms' });
  const [legalContent, setLegalContent] = useState({ terms: '', privacy: '' });

  useEffect(() => {
    const fetchLegal = async () => {
      const path = 'settings/global';
      try {
        const settingsDoc = await getDoc(doc(db, 'settings', 'global'));
        if (settingsDoc.exists()) {
          const data = settingsDoc.data();
          setLegalContent({
            terms: data.termsOfConditions || 'Terms of conditions are currently being updated.',
            privacy: data.privacyPolicy || 'Privacy policy is currently being updated.'
          });
        } else {
          setLegalContent({
            terms: 'Welcome to StoryCraft. By using our service, you agree to craft responsibly and respect the creative rights of others.',
            privacy: 'Your privacy is important to us. We protect your data with care.'
          });
        }
      } catch (error) {
        setLegalContent({
          terms: 'Welcome to StoryCraft. By using our service, you agree to craft responsibly.',
          privacy: 'Your privacy is important to us.'
        });
        handleFirestoreError(error, OperationType.GET, path);
      }
    };
    fetchLegal();
  }, []);

  const handleGoogleSignIn = async () => {
    const provider = new GoogleAuthProvider();
    try {
      setLoading(true);
      const result = await signInWithPopup(auth, provider);
      const user = result.user;
      
      const path = `users/${user.uid}`;
      try {
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        if (!userDoc.exists()) {
          await setDoc(doc(db, 'users', user.uid), {
            uid: user.uid,
            email: user.email,
            displayName: user.displayName || 'Anonymous',
            role: user.email === 'alaa.abukhamseen@gmail.com' ? 'headadmin' : 'user',
            subscriptionTier: 'free',
            subscriptionStatus: 'active',
            subscriptionCycle: 'none',
            streak: 0,
            tokens: 5,
            createdAt: Date.now()
          });
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, path);
      }
      toast.success('Welcome to StoryCraft!');
    } catch (error: any) {
      console.error(error);
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return toast.error('Please fill in all fields');
    
    try {
      setLoading(true);
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
        toast.success('Welcome back!');
      } else {
        const result = await createUserWithEmailAndPassword(auth, email, password);
        const user = result.user;
        await setDoc(doc(db, 'users', user.uid), {
          uid: user.uid,
          email: user.email,
          displayName: email.split('@')[0],
          role: email === 'alaa.abukhamseen@gmail.com' ? 'headadmin' : 'user',
          subscriptionTier: 'free',
          subscriptionStatus: 'active',
          subscriptionCycle: 'none',
          streak: 0,
          tokens: 5,
          createdAt: Date.now()
        });
        toast.success('Account created successfully!');
      }
    } catch (error: any) {
      console.error(error);
      toast.error(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen grid grid-cols-1 lg:grid-cols-2 bg-gradient-to-br from-slate-50 via-purple-50 to-orange-50 overflow-hidden">
      
      {/* Left: Branding */}
      <div className="hidden lg:flex flex-col justify-center p-16 relative">
        {/* Floating Gradients */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-60">
          <motion.div 
            animate={{ 
              x: [0, 50, 0],
              y: [0, -30, 0],
              scale: [1, 1.1, 1],
            }}
            transition={{ duration: 15, repeat: Infinity }}
            className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full blur-3xl"
          />
          <motion.div 
            animate={{ 
              x: [0, -40, 0],
              y: [0, 50, 0],
              scale: [1, 1.2, 1],
            }}
            transition={{ duration: 18, repeat: Infinity }}
            className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-gradient-to-br from-orange-300 to-yellow-300 rounded-full blur-3xl"
          />
        </div>

        <motion.div 
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="relative z-10"
        >
          <div className="flex items-center gap-3 mb-12">
            <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-lg shadow-purple-500/30">
              <Sparkles size={28} className="text-white" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              StoryCraft
            </span>
          </div>
          
          <h1 className="text-6xl font-bold leading-tight mb-6">
            Create Stories<br />
            That <span className="bg-gradient-to-r from-purple-600 via-pink-600 to-orange-500 bg-clip-text text-transparent">
              Inspire
            </span>
          </h1>
          
          <p className="text-slate-600 text-xl leading-relaxed max-w-lg mb-12">
            Join thousands of storytellers crafting beautiful, professional books with their own words and images.
          </p>

          {/* Stats */}
          <div className="flex gap-12">
            <div>
              <div className="text-4xl font-bold text-slate-900 mb-1">10K+</div>
              <div className="text-sm text-slate-600 font-medium">Stories Created</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-slate-900 mb-1">50+</div>
              <div className="text-sm text-slate-600 font-medium">Custom Themes</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-slate-900 mb-1">4.9★</div>
              <div className="text-sm text-slate-600 font-medium">User Rating</div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Right: Auth Form */}
      <div className="flex items-center justify-center p-8 bg-white/50 backdrop-blur-sm relative">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          {/* Card */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl p-10">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-slate-900 mb-2">
                {isLogin ? 'Welcome Back' : 'Join StoryCraft'}
              </h2>
              <p className="text-slate-600">
                {isLogin ? 'Sign in to continue your creative journey' : 'Create your account to start crafting'}
              </p>
            </div>

            {/* Google Sign In */}
            <button 
              onClick={handleGoogleSignIn}
              disabled={loading}
              className="w-full bg-white border-2 border-slate-200 text-slate-700 font-semibold py-4 rounded-xl hover:bg-slate-50 hover:border-slate-300 transition-all flex items-center justify-center gap-3 mb-6 disabled:opacity-50"
            >
              <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-5 h-5" alt="Google" />
              <span>Continue with Google</span>
            </button>

            <div className="relative mb-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="bg-white px-4 text-slate-500">Or with email</span>
              </div>
            </div>

            {/* Email Form */}
            <form onSubmit={handleEmailAuth} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">Email</label>
                <div className="relative">
                  <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-4 focus:ring-purple-500/20 focus:border-purple-500 transition-all"
                    placeholder="you@example.com"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-slate-700">Password</label>
                <div className="relative">
                  <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-4 focus:ring-purple-500/20 focus:border-purple-500 transition-all"
                    placeholder="••••••••"
                  />
                </div>
              </div>

              <button 
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold py-4 rounded-xl hover:scale-[1.02] hover:shadow-xl hover:shadow-purple-500/30 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed mt-6"
              >
                {loading ? (
                  <Loader2 className="animate-spin" size={20} />
                ) : isLogin ? (
                  <>
                    <LogIn size={20} />
                    <span>Sign In</span>
                  </>
                ) : (
                  <>
                    <UserPlus size={20} />
                    <span>Create Account</span>
                  </>
                )}
              </button>
            </form>

            {/* Toggle */}
            <div className="text-center mt-6">
              <button 
                onClick={() => setIsLogin(!isLogin)}
                className="text-purple-600 hover:text-purple-700 font-semibold text-sm transition-colors"
              >
                {isLogin ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
              </button>
            </div>

            {/* Legal */}
            <div className="text-center mt-8 pt-6 border-t border-slate-200">
              <p className="text-xs text-slate-500">
                By continuing, you agree to our{' '}
                <button 
                  onClick={() => setShowLegal({ show: true, type: 'terms' })}
                  className="text-purple-600 hover:text-purple-700 font-medium underline underline-offset-2"
                >
                  Terms
                </button>
                {' '}and{' '}
                <button 
                  onClick={() => setShowLegal({ show: true, type: 'privacy' })}
                  className="text-purple-600 hover:text-purple-700 font-medium underline underline-offset-2"
                >
                  Privacy Policy
                </button>
              </p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Legal Modal */}
      <AnimatePresence>
        {showLegal.show && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }}
              onClick={() => setShowLegal({ ...showLegal, show: false })}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-2xl bg-white rounded-3xl border border-slate-200 shadow-2xl p-10 flex flex-col max-h-[80vh]"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center shadow-lg">
                    <FileText size={24} className="text-white" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-slate-900">
                      {showLegal.type === 'terms' ? 'Terms of Service' : 'Privacy Policy'}
                    </h3>
                    <p className="text-sm text-slate-600">Last updated: January 2026</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowLegal({ ...showLegal, show: false })} 
                  className="p-2 hover:bg-slate-100 rounded-xl transition-all text-slate-600 hover:text-slate-900"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto pr-4">
                <div className="text-slate-700 text-sm leading-relaxed whitespace-pre-wrap">
                  {showLegal.type === 'terms' ? legalContent.terms : legalContent.privacy}
                </div>
              </div>

              <button 
                onClick={() => setShowLegal({ ...showLegal, show: false })}
                className="mt-6 w-full py-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold rounded-xl hover:scale-[1.02] transition-all shadow-lg"
              >
                I Understand
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
