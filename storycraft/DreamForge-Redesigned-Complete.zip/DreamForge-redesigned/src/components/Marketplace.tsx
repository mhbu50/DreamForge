import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowLeft, Star, Download, Search, Filter, TrendingUp, Clock, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Marketplace() {
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const themes = [
    {
      id: 1,
      name: 'Watercolor Dream',
      author: 'Sarah Chen',
      downloads: 1234,
      rating: 4.8,
      preview: 'https://picsum.photos/seed/theme1/400/300',
      category: 'Artistic'
    },
    {
      id: 2,
      name: 'Midnight Tales',
      author: 'Alex Rivera',
      downloads: 2156,
      rating: 4.9,
      preview: 'https://picsum.photos/seed/theme2/400/300',
      category: 'Dark'
    },
    {
      id: 3,
      name: 'Nordic Simplicity',
      author: 'Emma Larsson',
      downloads: 891,
      rating: 4.7,
      preview: 'https://picsum.photos/seed/theme3/400/300',
      category: 'Minimal'
    },
    {
      id: 4,
      name: 'Vintage Storybook',
      author: 'James Cooper',
      downloads: 1567,
      rating: 4.6,
      preview: 'https://picsum.photos/seed/theme4/400/300',
      category: 'Vintage'
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-orange-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <Link to="/" className="p-2 hover:bg-slate-100 rounded-xl transition-colors">
                <ArrowLeft size={24} className="text-slate-700" />
              </Link>
              <div>
                <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  Theme Marketplace
                </h1>
                <p className="text-slate-600 mt-1">Discover beautiful themes for your stories</p>
              </div>
            </div>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1 max-w-md">
              <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search themes..."
                className="w-full pl-12 pr-4 py-3 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-4 focus:ring-purple-500/20 focus:border-purple-500 transition-all"
              />
            </div>

            <div className="flex gap-2">
              {['All', 'Artistic', 'Dark', 'Minimal', 'Vintage'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setFilter(cat.toLowerCase())}
                  className={`px-5 py-2.5 rounded-xl font-semibold whitespace-nowrap transition-all ${
                    filter === cat.toLowerCase()
                      ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg shadow-purple-500/30'
                      : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-6 py-12">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {[
            { label: 'Total Themes', value: '50+', icon: <TrendingUp size={24} /> },
            { label: 'New This Week', value: '5', icon: <Clock size={24} /> },
            { label: 'Most Popular', value: 'Midnight Tales', icon: <Star size={24} /> }
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white rounded-2xl p-6 border border-slate-200 hover:shadow-lg transition-all"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-600 font-medium">{stat.label}</span>
                <div className="text-purple-500">{stat.icon}</div>
              </div>
              <p className="text-3xl font-bold text-slate-900">{stat.value}</p>
            </motion.div>
          ))}
        </div>

        {/* Themes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {themes.map((theme, i) => (
            <motion.div
              key={theme.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="group bg-white rounded-2xl overflow-hidden border border-slate-200 hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 cursor-pointer"
            >
              {/* Preview Image */}
              <div className="relative aspect-[4/3] overflow-hidden bg-gradient-to-br from-purple-100 to-pink-100">
                <img 
                  src={theme.preview} 
                  alt={theme.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                
                {/* Category Badge */}
                <div className="absolute top-3 left-3">
                  <span className="px-3 py-1 bg-white/90 backdrop-blur-sm rounded-full text-xs font-semibold text-slate-700">
                    {theme.category}
                  </span>
                </div>

                {/* Like Button */}
                <button className="absolute top-3 right-3 w-10 h-10 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:scale-110">
                  <Heart size={18} className="text-red-500" />
                </button>
              </div>

              {/* Info */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-slate-900 mb-1">{theme.name}</h3>
                <p className="text-sm text-slate-600 mb-4">by {theme.author}</p>

                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-1">
                    <Star size={16} className="fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-semibold text-slate-700">{theme.rating}</span>
                  </div>
                  <div className="flex items-center gap-1 text-sm text-slate-600">
                    <Download size={16} />
                    <span>{theme.downloads.toLocaleString()}</span>
                  </div>
                </div>

                <button className="w-full py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl font-semibold hover:scale-105 hover:shadow-lg hover:shadow-purple-500/30 transition-all flex items-center justify-center gap-2">
                  <Download size={18} />
                  <span>Install Theme</span>
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </main>
    </div>
  );
}
