import React from 'react';
import Marketplace from './Marketplace';

// ThemeMarketplace is just an alias for Marketplace
export default function ThemeMarketplace() {
  return <Marketplace />;
}
