import React from 'react';

export default function DesignInspiration() {
  return (
    <div className="p-8">
      <h2 className="text-2xl font-bold mb-4">Design Inspiration</h2>
      <p className="text-slate-600">Browse design inspiration and templates.</p>
    </div>
  );
}
