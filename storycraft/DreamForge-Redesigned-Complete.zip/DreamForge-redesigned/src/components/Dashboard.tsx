import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Plus, BookOpen, Clock, Star, TrendingUp, Palette, 
  Search, Filter, MoreVertical, Edit3, Trash2, Share2,
  FolderOpen, Grid, List, Calendar
} from 'lucide-react';

export default function Dashboard() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [filter, setFilter] = useState('all');

  const stories = [
    {
      id: 1,
      title: 'The Midnight Garden',
      cover: 'https://picsum.photos/seed/story1/400/600',
      lastEdited: '2 hours ago',
      progress: 75,
      pages: 42,
      status: 'In Progress'
    },
    {
      id: 2,
      title: 'Adventures in Space',
      cover: 'https://picsum.photos/seed/story2/400/600',
      lastEdited: 'Yesterday',
      progress: 100,
      pages: 56,
      status: 'Complete'
    },
    {
      id: 3,
      title: 'The Lost Treasure',
      cover: 'https://picsum.photos/seed/story3/400/600',
      lastEdited: '3 days ago',
      progress: 25,
      pages: 18,
      status: 'In Progress'
    },
    {
      id: 4,
      title: 'Dreams of Tomorrow',
      cover: 'https://picsum.photos/seed/story4/400/600',
      lastEdited: '1 week ago',
      progress: 50,
      pages: 28,
      status: 'In Progress'
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-orange-50">
      
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
                My Stories
              </h1>
              <p className="text-slate-600">Continue crafting your masterpieces</p>
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl font-semibold flex items-center gap-2 shadow-lg shadow-purple-500/30 hover:shadow-xl hover:shadow-purple-500/40 transition-all"
            >
              <Plus size={20} />
              <span>New Story</span>
            </motion.button>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            {[
              { label: 'Total Stories', value: '12', icon: <BookOpen size={20} />, color: 'purple' },
              { label: 'In Progress', value: '8', icon: <Clock size={20} />, color: 'blue' },
              { label: 'Completed', value: '4', icon: <Star size={20} />, color: 'green' },
              { label: 'Total Pages', value: '342', icon: <TrendingUp size={20} />, color: 'orange' }
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-white rounded-2xl p-5 border border-slate-200 hover:shadow-lg transition-all"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-slate-600 text-sm font-medium">{stat.label}</span>
                  <div className={`text-${stat.color}-500`}>{stat.icon}</div>
                </div>
                <p className="text-3xl font-bold text-slate-900">{stat.value}</p>
              </motion.div>
            ))}
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
            <div className="relative flex-1 max-w-md w-full">
              <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search your stories..."
                className="w-full pl-12 pr-4 py-3 bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-4 focus:ring-purple-500/20 focus:border-purple-500 transition-all"
              />
            </div>

            <div className="flex items-center gap-3">
              <button className="px-4 py-2.5 bg-white rounded-xl border border-slate-200 text-slate-700 font-medium hover:bg-slate-50 transition-all flex items-center gap-2">
                <Filter size={18} />
                <span>Filter</span>
              </button>

              <div className="flex bg-white rounded-xl border border-slate-200 p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded-lg transition-all ${
                    viewMode === 'grid' 
                      ? 'bg-purple-100 text-purple-600' 
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <Grid size={18} />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded-lg transition-all ${
                    viewMode === 'list' 
                      ? 'bg-purple-100 text-purple-600' 
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  <List size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        
        {/* Filter Tabs */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
          {['All Stories', 'In Progress', 'Completed', 'Drafts', 'Favorites'].map((tab) => (
            <button
              key={tab}
              onClick={() => setFilter(tab.toLowerCase().replace(' ', '-'))}
              className={`px-5 py-2.5 rounded-xl font-semibold whitespace-nowrap transition-all ${
                filter === tab.toLowerCase().replace(' ', '-')
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg shadow-purple-500/30'
                  : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Stories Grid/List */}
        {viewMode === 'grid' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {stories.map((story, i) => (
              <motion.div
                key={story.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="group bg-white rounded-2xl overflow-hidden border border-slate-200 hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 cursor-pointer"
              >
                {/* Cover Image */}
                <div className="relative aspect-[3/4] overflow-hidden bg-gradient-to-br from-purple-100 to-pink-100">
                  <img 
                    src={story.cover} 
                    alt={story.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  
                  {/* Floating Actions */}
                  <div className="absolute top-3 right-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="w-9 h-9 bg-white rounded-xl flex items-center justify-center shadow-lg hover:scale-110 transition-transform">
                      <Edit3 size={16} className="text-purple-600" />
                    </button>
                    <button className="w-9 h-9 bg-white rounded-xl flex items-center justify-center shadow-lg hover:scale-110 transition-transform">
                      <Share2 size={16} className="text-blue-600" />
                    </button>
                  </div>

                  {/* Status Badge */}
                  <div className="absolute top-3 left-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold backdrop-blur-sm ${
                      story.status === 'Complete'
                        ? 'bg-green-500/90 text-white'
                        : 'bg-orange-500/90 text-white'
                    }`}>
                      {story.status}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-5">
                  <h3 className="text-lg font-bold text-slate-900 mb-2 line-clamp-1">
                    {story.title}
                  </h3>
                  
                  <div className="flex items-center gap-4 text-sm text-slate-600 mb-4">
                    <div className="flex items-center gap-1">
                      <BookOpen size={14} />
                      <span>{story.pages} pages</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock size={14} />
                      <span>{story.lastEdited}</span>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-600 font-medium">Progress</span>
                      <span className="text-purple-600 font-bold">{story.progress}%</span>
                    </div>
                    <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${story.progress}%` }}
                        transition={{ duration: 1, delay: i * 0.1 }}
                        className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
                      />
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}

            {/* Add New Story Card */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: stories.length * 0.1 }}
              className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl border-2 border-dashed border-purple-300 hover:border-purple-500 hover:shadow-xl transition-all duration-300 cursor-pointer flex items-center justify-center min-h-[400px] group"
            >
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform shadow-lg">
                  <Plus size={32} className="text-white" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">Create New Story</h3>
                <p className="text-slate-600">Start your next masterpiece</p>
              </div>
            </motion.div>
          </div>
        ) : (
          /* List View */
          <div className="space-y-4">
            {stories.map((story, i) => (
              <motion.div
                key={story.id}
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-white rounded-2xl p-6 border border-slate-200 hover:shadow-xl hover:-translate-x-2 transition-all duration-300 cursor-pointer"
              >
                <div className="flex items-center gap-6">
                  {/* Thumbnail */}
                  <div className="w-24 h-32 rounded-xl overflow-hidden bg-gradient-to-br from-purple-100 to-pink-100 flex-shrink-0">
                    <img 
                      src={story.cover} 
                      alt={story.title}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-xl font-bold text-slate-900 mb-1">{story.title}</h3>
                        <p className="text-sm text-slate-600">Last edited {story.lastEdited}</p>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        story.status === 'Complete'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-orange-100 text-orange-700'
                      }`}>
                        {story.status}
                      </span>
                    </div>

                    <div className="flex items-center gap-6 mb-4">
                      <div className="flex items-center gap-2 text-sm text-slate-600">
                        <BookOpen size={16} />
                        <span>{story.pages} pages</span>
                      </div>
                      <div className="flex-1 max-w-xs">
                        <div className="flex items-center justify-between text-sm mb-1">
                          <span className="text-slate-600 font-medium">Progress</span>
                          <span className="text-purple-600 font-bold">{story.progress}%</span>
                        </div>
                        <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                          <div 
                            style={{ width: `${story.progress}%` }}
                            className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button className="px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl text-sm font-semibold hover:scale-105 transition-transform flex items-center gap-2">
                        <Edit3 size={16} />
                        <span>Continue Writing</span>
                      </button>
                      <button className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-sm font-semibold hover:bg-slate-200 transition-all flex items-center gap-2">
                        <Share2 size={16} />
                        <span>Share</span>
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
