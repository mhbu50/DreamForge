import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, BookOpen, Wand2, Heart, Zap, Users, ChevronRight, Star, Palette, PenTool } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-orange-50 text-slate-900 overflow-x-hidden">
      
      {/* Floating Blob Backgrounds */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none opacity-40">
        <motion.div 
          animate={{ 
            x: [0, 100, 0],
            y: [0, -50, 0],
            scale: [1, 1.1, 1],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full blur-3xl"
        />
        <motion.div 
          animate={{ 
            x: [0, -80, 0],
            y: [0, 100, 0],
            scale: [1, 1.2, 1],
          }}
          transition={{ duration: 25, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-gradient-to-br from-orange-300 to-yellow-300 rounded-full blur-3xl"
        />
        <motion.div 
          animate={{ 
            x: [0, 50, 0],
            y: [0, -80, 0],
            scale: [1, 1.15, 1],
          }}
          transition={{ duration: 22, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-1/3 right-1/4 w-80 h-80 bg-gradient-to-br from-blue-400 to-cyan-400 rounded-full blur-3xl"
        />
      </div>

      {/* Navigation */}
      <nav className="relative z-50 px-6 md:px-12 py-6 flex items-center justify-between backdrop-blur-sm bg-white/60 border-b border-slate-200/50 sticky top-0">
        <div className="flex items-center gap-3 group">
          <div className="w-11 h-11 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-lg shadow-purple-500/30 group-hover:scale-110 transition-transform">
            <Sparkles size={22} className="text-white" />
          </div>
          <span className="font-bold text-2xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            StoryCraft
          </span>
        </div>
        
        <div className="hidden md:flex items-center gap-8">
          <a href="#features" className="text-sm font-semibold text-slate-600 hover:text-purple-600 transition-colors">Features</a>
          <Link to="/marketplace" className="text-sm font-semibold text-slate-600 hover:text-purple-600 transition-colors">Marketplace</Link>
          <div className="flex items-center gap-3">
            <Link to="/login" className="px-6 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-100 rounded-xl transition-all">
              Sign In
            </Link>
            <Link to="/login" className="px-6 py-2.5 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl text-sm font-semibold hover:scale-105 hover:shadow-lg hover:shadow-purple-500/30 transition-all">
              Get Started Free
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-20 pb-32 px-6">
        <div className="container mx-auto max-w-7xl relative z-10">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            
            {/* Left: Text Content */}
            <div>
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-full border border-purple-200 shadow-sm mb-8"
              >
                <Zap size={16} className="text-purple-600" />
                <span className="text-xs font-bold text-purple-600 uppercase tracking-wider">
                  The Ultimate Story Studio
                </span>
              </motion.div>
              
              <motion.h1 
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="text-6xl md:text-7xl font-bold leading-[1.1] mb-6"
              >
                Craft Stories That
                <span className="block mt-2 bg-gradient-to-r from-purple-600 via-pink-600 to-orange-500 bg-clip-text text-transparent">
                  Come Alive
                </span>
              </motion.h1>

              <motion.p 
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="text-xl text-slate-600 leading-relaxed mb-10 max-w-xl"
              >
                Create beautiful, professional books with your own words and images. 
                No design skills needed—just your imagination.
              </motion.p>

              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="flex flex-col sm:flex-row gap-4"
              >
                <Link to="/login" className="group px-8 py-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl font-bold text-lg hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/40 transition-all flex items-center justify-center gap-3">
                  <Wand2 size={24} />
                  <span>Start Creating Free</span>
                  <ChevronRight size={20} className="group-hover:translate-x-1 transition-transform" />
                </Link>
                <button className="px-8 py-4 bg-white/80 backdrop-blur-sm text-slate-700 rounded-2xl font-semibold text-lg hover:bg-white hover:shadow-xl transition-all border border-slate-200">
                  Watch Demo
                </button>
              </motion.div>

              {/* Social Proof */}
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="mt-12 flex items-center gap-8"
              >
                <div className="flex -space-x-3">
                  {[1, 2, 3, 4].map(i => (
                    <div key={i} className="w-10 h-10 rounded-full border-2 border-white bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center text-white font-bold text-sm">
                      {String.fromCharCode(64 + i)}
                    </div>
                  ))}
                </div>
                <div>
                  <div className="flex gap-1 mb-1">
                    {[1, 2, 3, 4, 5].map(i => (
                      <Star key={i} size={14} className="fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-sm text-slate-600">
                    <span className="font-bold">10,000+</span> stories created
                  </p>
                </div>
              </motion.div>
            </div>

            {/* Right: Visual Element */}
            <motion.div 
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative hidden md:block"
            >
              {/* Floating Cards */}
              <div className="relative w-full aspect-square">
                
                {/* Main Card */}
                <motion.div 
                  animate={{ y: [0, -15, 0] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-96 bg-white rounded-3xl shadow-2xl overflow-hidden"
                >
                  <div className="h-48 bg-gradient-to-br from-purple-400 via-pink-400 to-orange-300 relative">
                    <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-30" />
                  </div>
                  <div className="p-6">
                    <div className="w-12 h-1.5 bg-slate-200 rounded-full mb-3" />
                    <div className="w-full h-1 bg-slate-200 rounded-full mb-2" />
                    <div className="w-full h-1 bg-slate-200 rounded-full mb-2" />
                    <div className="w-3/4 h-1 bg-slate-200 rounded-full" />
                  </div>
                </motion.div>

                {/* Floating Icon 1 */}
                <motion.div 
                  animate={{ 
                    y: [0, -20, 0],
                    rotate: [0, 5, 0]
                  }}
                  transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute top-0 right-0 w-16 h-16 bg-white rounded-2xl shadow-xl flex items-center justify-center"
                >
                  <Palette size={28} className="text-purple-500" />
                </motion.div>

                {/* Floating Icon 2 */}
                <motion.div 
                  animate={{ 
                    y: [0, 15, 0],
                    rotate: [0, -5, 0]
                  }}
                  transition={{ duration: 6, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                  className="absolute bottom-8 left-0 w-16 h-16 bg-white rounded-2xl shadow-xl flex items-center justify-center"
                >
                  <PenTool size={28} className="text-pink-500" />
                </motion.div>

                {/* Floating Icon 3 */}
                <motion.div 
                  animate={{ 
                    y: [0, -10, 0],
                    x: [0, 10, 0]
                  }}
                  transition={{ duration: 7, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                  className="absolute top-24 left-8 w-14 h-14 bg-gradient-to-br from-orange-400 to-yellow-400 rounded-xl shadow-lg flex items-center justify-center"
                >
                  <Heart size={24} className="text-white" />
                </motion.div>
              </div>
            </motion.div>

          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 px-6 relative z-10">
        <div className="container mx-auto max-w-7xl">
          
          <div className="text-center max-w-3xl mx-auto mb-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-5xl md:text-6xl font-bold mb-6">
                Everything You Need to
                <span className="block mt-2 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  Tell Your Story
                </span>
              </h2>
              <p className="text-xl text-slate-600">
                Powerful tools that make creating beautiful books effortless
              </p>
            </motion.div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: <PenTool className="text-purple-600" size={32} />,
                title: "Intuitive Editor",
                desc: "Write and format your story with a beautiful, distraction-free editor. Rich text, markdown support, and real-time preview.",
                color: "from-purple-500/10 to-pink-500/10",
                borderColor: "border-purple-200"
              },
              {
                icon: <Palette className="text-pink-600" size={32} />,
                title: "Your Own Images",
                desc: "Upload your photos and illustrations. Drag, drop, resize, and position them exactly where you want on every page.",
                color: "from-pink-500/10 to-orange-500/10",
                borderColor: "border-pink-200"
              },
              {
                icon: <BookOpen className="text-orange-600" size={32} />,
                title: "Book-Like Layout",
                desc: "Read and create in a stunning two-page spread that feels just like holding a real book in your hands.",
                color: "from-orange-500/10 to-yellow-500/10",
                borderColor: "border-orange-200"
              },
              {
                icon: <Sparkles className="text-blue-600" size={32} />,
                title: "Beautiful Themes",
                desc: "Choose from dozens of professionally designed themes or customize colors, fonts, and layouts to match your vision.",
                color: "from-blue-500/10 to-cyan-500/10",
                borderColor: "border-blue-200"
              },
              {
                icon: <Users className="text-green-600" size={32} />,
                title: "Collaborate",
                desc: "Work together with co-authors, editors, and illustrators. Share feedback and track changes in real-time.",
                color: "from-green-500/10 to-emerald-500/10",
                borderColor: "border-green-200"
              },
              {
                icon: <Heart className="text-red-600" size={32} />,
                title: "Export Anywhere",
                desc: "Download your book as PDF, ePub, or print-ready formats. Publish to Amazon KDP or share online instantly.",
                color: "from-red-500/10 to-pink-500/10",
                borderColor: "border-red-200"
              }
            ].map((feature, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`group p-8 bg-gradient-to-br ${feature.color} backdrop-blur-sm rounded-3xl border ${feature.borderColor} hover:scale-105 hover:shadow-2xl transition-all duration-300`}
              >
                <div className="w-16 h-16 bg-white rounded-2xl shadow-lg flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  {feature.icon}
                </div>
                <h3 className="text-2xl font-bold mb-3 text-slate-900">{feature.title}</h3>
                <p className="text-slate-600 leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-24 px-6">
        <div className="container mx-auto max-w-6xl">
          <div className="bg-white/80 backdrop-blur-sm rounded-[3rem] border border-slate-200 shadow-2xl p-12 md:p-16">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
              {[
                { val: "10K+", label: "Stories Created", icon: <BookOpen size={32} /> },
                { val: "50+", label: "Custom Themes", icon: <Palette size={32} /> },
                { val: "4.9★", label: "User Rating", icon: <Star size={32} /> },
                { val: "24/7", label: "Support", icon: <Heart size={32} /> }
              ].map((stat, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="space-y-3"
                >
                  <div className="flex justify-center text-purple-500 mb-2">
                    {stat.icon}
                  </div>
                  <span className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent block">
                    {stat.val}
                  </span>
                  <p className="text-sm font-semibold text-slate-600 uppercase tracking-wider">
                    {stat.label}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 opacity-90" />
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-20" />
        
        <div className="container mx-auto max-w-4xl text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <h2 className="text-5xl md:text-7xl font-bold text-white leading-tight">
              Ready to Craft Your
              <span className="block mt-2">Masterpiece?</span>
            </h2>
            <p className="text-xl md:text-2xl text-white/90 max-w-2xl mx-auto font-medium">
              Join thousands of storytellers who have brought their imagination to life
            </p>
            <Link to="/login" className="inline-flex items-center gap-4 px-10 py-5 bg-white text-purple-600 rounded-2xl font-bold text-xl hover:scale-105 hover:shadow-2xl transition-all group">
              <span>Start Creating for Free</span>
              <ChevronRight size={24} className="group-hover:translate-x-2 transition-transform" />
            </Link>
            <p className="text-white/80 text-sm">No credit card required • Free forever</p>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-16 border-t border-slate-200 bg-white/60 backdrop-blur-sm px-6">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center shadow-lg">
                <Sparkles size={20} className="text-white" />
              </div>
              <span className="font-bold text-xl bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                StoryCraft
              </span>
            </div>
            <div className="flex gap-8">
              {['Twitter', 'Discord', 'Instagram', 'GitHub'].map(social => (
                <a key={social} href="#" className="text-sm font-semibold text-slate-600 hover:text-purple-600 transition-colors">
                  {social}
                </a>
              ))}
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-slate-200 text-center">
            <p className="text-sm text-slate-500">
              © 2026 StoryCraft. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
