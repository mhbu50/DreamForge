import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { onAuthStateChanged } from 'firebase/auth';
import { doc, getDoc, onSnapshot } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from './lib/firestore-utils';
import { auth, db } from './firebase';
import { UserProfile, Theme } from './types';
import { SystemHealthService } from './services/SystemHealthService';
import Auth from './components/Auth';
import Dashboard from './components/Dashboard';
import Admin from './components/Admin';
import Marketplace from './components/Marketplace';
import Landing from './components/Landing';
import CommandPalette from './components/CommandPalette';
import ErrorBoundary from './components/ErrorBoundary';
import { Toaster } from 'sonner';
import { Loader2, Wrench } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [globalSettings, setGlobalSettings] = useState<any>(null);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
        e.preventDefault();
        setIsCommandPaletteOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    const path = 'settings/global';
    const unsubscribeSettings = onSnapshot(doc(db, 'settings', 'global'), (snapshot) => {
      if (snapshot.exists()) {
        setGlobalSettings(snapshot.data());
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });

    const unsubscribeAuth = onAuthStateChanged(auth, (authUser) => {
      if (authUser) {
        setUser(authUser);
        const userPath = `users/${authUser.uid}`;
        
        const unsubProfile = onSnapshot(doc(db, 'users', authUser.uid), (snapshot) => {
          if (snapshot.exists()) {
            const profile = snapshot.data() as UserProfile;
            setUserProfile(profile);
            
            if (profile.role === 'headadmin' || authUser.email === 'alaa.abukhamseen@gmail.com') {
              SystemHealthService.getInstance().runFullCheck();
            }
          }
          setLoading(false);
        }, (error) => {
          handleFirestoreError(error, OperationType.GET, userPath);
          setLoading(false);
        });

        return unsubProfile;
      } else {
        setUser(null);
        setUserProfile(null);
        setLoading(false);
      }
    });

    return () => {
      unsubscribeSettings();
      unsubscribeAuth();
    };
  }, []);

  useEffect(() => {
    if (userProfile?.activeThemeId) {
      const fetchTheme = async () => {
        try {
          const themeDoc = await getDoc(doc(db, 'themes', userProfile.activeThemeId!));
          if (themeDoc.exists()) {
            const themeData = themeDoc.data() as Theme;
            let styleTag = document.getElementById('storycraft-custom-theme');
            if (!styleTag) {
              styleTag = document.createElement('style');
              styleTag.id = 'storycraft-custom-theme';
              document.head.appendChild(styleTag);
            }
            styleTag.innerHTML = themeData.css;
          }
        } catch (error) {
          console.error("Failed to fetch theme:", error);
        }
      };
      fetchTheme();
    } else {
      const styleTag = document.getElementById('storycraft-custom-theme');
      if (styleTag) styleTag.innerHTML = '';
    }
  }, [userProfile?.activeThemeId]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 via-purple-50 to-orange-50">
        <div className="flex flex-col items-center gap-6">
          <div className="relative">
            <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-2xl shadow-purple-500/30 animate-pulse-scale">
              <Loader2 className="animate-spin text-white" size={36} />
            </div>
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl blur-xl opacity-50 animate-pulse" />
          </div>
          <div className="text-center">
            <p className="text-lg font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent animate-pulse">
              Loading your stories...
            </p>
            <p className="text-sm text-slate-600 mt-1">Just a moment</p>
          </div>
        </div>
      </div>
    );
  }

  // Maintenance Mode
  if (globalSettings?.maintenanceMode && userProfile?.role !== 'headadmin') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-8">
        <div className="max-w-md w-full text-center space-y-8">
          <div className="relative">
            <div className="w-24 h-24 bg-gradient-to-br from-purple-500 to-pink-500 rounded-3xl flex items-center justify-center text-white mx-auto shadow-2xl">
              <Wrench size={48} />
            </div>
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500 to-pink-500 rounded-3xl blur-2xl opacity-50 animate-pulse" />
          </div>
          <div className="space-y-4">
            <h1 className="text-4xl font-bold text-white">We'll Be Right Back</h1>
            <p className="text-white/70 leading-relaxed text-lg">
              We're making StoryCraft even better. Check back soon for exciting new features!
            </p>
          </div>
          <div className="pt-8 border-t border-white/10">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full">
              <div className="w-2 h-2 bg-orange-400 rounded-full animate-pulse" />
              <span className="text-xs font-semibold text-white uppercase tracking-wider">
                Under Maintenance
              </span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <Router>
        <Toaster position="top-center" richColors />
        <CommandPalette 
          isOpen={isCommandPaletteOpen} 
          onClose={() => setIsCommandPaletteOpen(false)} 
        />
        <Routes>
          <Route 
            path="/login" 
            element={user ? <Navigate to="/" /> : <Auth />} 
          />
          <Route 
            path="/" 
            element={user ? <Dashboard userProfile={userProfile} /> : <Landing />} 
          />
          <Route 
            path="/marketplace" 
            element={<Marketplace />} 
          />
          <Route 
            path="/admin" 
            element={
              user && (userProfile?.role === 'admin' || userProfile?.role === 'headadmin' || user.email === 'alaa.abukhamseen@gmail.com') ? (
                <Admin />
              ) : (
                <Navigate to="/" />
              )
            } 
          />
        </Routes>
      </Router>
    </ErrorBoundary>
  );
}
